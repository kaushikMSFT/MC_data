using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuditorAPI.Config;
using AuditorAPI.Domain;
using AuditorAPI.EventConsumers;
using AuditorAPI.Persistence;
using AuditorAPI.Services;
using AuditorAPI.UnitOfWork;
using MassTransit;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace AuditorAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<AuditDbContext>(options =>
              options.UseSqlServer(
                  Configuration.GetConnectionString("DefaultConnection")));
            services.AddMassTransit(x =>
            {
                x.AddConsumer<AuditorProfileEventConsumer>();
                x.AddBus(provider => Bus.Factory.CreateUsingRabbitMq(config =>
                {
                    config.Host("rabbitmq://localhost");
                    config.ReceiveEndpoint("Auditor-Topic", endpoint =>
                    {
                        endpoint.PrefetchCount = 10;
                        endpoint.ConfigureConsumer<AuditorProfileEventConsumer>(provider);
                    });
                }));
            });

            services.AddMassTransitHostedService();
            services.AddSwaggerGen(
                x => {
                    x.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo() { Title = "AuditorAPI", Version = "v1" });
                   
                    

                });
            services.AddControllers();
         
            services.AddScoped<IAuditUnitOfWork, AuditorAPI.UnitOfWork.UnitOfWork>();
            services.AddScoped<IRepository<AuditPortfolio>, AuditPortfolioRepository>();
            services.AddScoped<AuditorAPI.Services.IAuditPortfolioService, AuditPortfolioService>();
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            SwaggerSettings swaggerSettings = new SwaggerSettings();
            Configuration.GetSection(nameof(SwaggerSettings)).Bind(swaggerSettings);
            app.UseSwagger(setting => { setting.RouteTemplate = swaggerSettings.JsonRoute; });
            app.UseSwaggerUI(setting => { setting.SwaggerEndpoint(swaggerSettings.UiEndpoint, swaggerSettings.Description); });

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
