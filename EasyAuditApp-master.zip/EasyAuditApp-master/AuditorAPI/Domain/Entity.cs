﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditorAPI.Domain
{
    public abstract class Entity
    {
        public int id;
    }
}
