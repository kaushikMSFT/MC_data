﻿using AuditorAPI.Domain;
using AuditorAPI.Persistence;
using AuditorAPI.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditorAPI.Services
{
    public class AuditPortfolioService : IAuditPortfolioService
    {
        private readonly IAuditUnitOfWork _unitOfWork;
        private readonly IRepository<AuditPortfolio> _portfoliorepository;
        public AuditPortfolioService(IAuditUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
            //_portfoliorepository = auditPortfolioRepository;
        }

        public void Create(AuditPortfolio portfolio)
        {
            _unitOfWork.AuditPortfolios.Add(portfolio);
            _unitOfWork.Save();
        }

        public IEnumerable<AuditPortfolio> GetAll()
        {
           return _unitOfWork.AuditPortfolios.GetAll();
        }
    }
}
