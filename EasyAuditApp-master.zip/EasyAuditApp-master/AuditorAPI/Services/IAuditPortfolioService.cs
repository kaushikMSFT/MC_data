﻿using AuditorAPI.Domain;
using System.Collections.Generic;

namespace AuditorAPI.Services
{
    public interface IAuditPortfolioService
    {
        void Create(AuditPortfolio portfolio);
        IEnumerable<AuditPortfolio> GetAll();
    }
}