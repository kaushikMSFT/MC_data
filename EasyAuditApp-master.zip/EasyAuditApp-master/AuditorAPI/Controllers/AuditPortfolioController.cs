﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AuditorAPI.Contracts;
using AuditorAPI.Domain;
using AuditorAPI.Persistence;
using AuditorAPI.Services;
using AuditorAPI.UnitOfWork;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AuditorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditPortfolioController : ControllerBase
    {
        private readonly IAuditPortfolioService _auditPortfolioService;
        private readonly IUnitOfWork _unitOfWork;
        public AuditPortfolioController(IAuditPortfolioService auditPorfolioService, IAuditUnitOfWork unitOfWork)
        {
            _auditPortfolioService = auditPorfolioService;
            _unitOfWork = unitOfWork;
        }
        // GET: api/<AuditPortfolioController>
        [HttpGet]
        public IEnumerable<AuditPortfolio> Get()
        {
            // return new string[] { "value1", "value2" };
           return _auditPortfolioService.GetAll();
        }

        // GET api/<AuditPortfolioController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<AuditPortfolioController>
        [HttpPost]
        public void Post([FromBody] AuditPortfolioCreationRequest auditPortfolioCreationRequest)
        {
            _auditPortfolioService.Create(new AuditPortfolio() { 
                ClientId=auditPortfolioCreationRequest.ClientId , ReportReleaseDate = auditPortfolioCreationRequest.ReportReleaseDate , Name=auditPortfolioCreationRequest.Name
            }
            );
        }

        // PUT api/<AuditPortfolioController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AuditPortfolioController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
